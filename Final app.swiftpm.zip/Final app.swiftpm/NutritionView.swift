import SwiftUI

struct Nutrition: View {
    var body: some View {
        VStack{
            
        }
    }
}
