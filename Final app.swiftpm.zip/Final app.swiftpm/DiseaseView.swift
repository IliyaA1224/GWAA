import SwiftUI

struct Disease: View {
    var body: some View {
        VStack{
            
            Text("Disease is spread already easily enough, but with global warming diseases could be spread at an alarming rate. One impact of global warming is the increase in vector ranges. Vectors are carriers of disease, these carriers coudl be things such as, mosquitoes and ticks. The increase of warm weatehr as a result of global warming allows for these carriers to live and survive in areas they are previously couldn’t.Another way that global warming has effected diseases is by fasilitating their spread. teampetures that result from global warming are causing laternation in the way disease is spread. These impoacts as a result could cause the death of many individuals due to doctors not finding cures in time, or diseases being stronger leading to mortality.")
            
            
            
        }
    }
}
