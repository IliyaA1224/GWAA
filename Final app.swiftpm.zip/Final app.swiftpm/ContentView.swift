import SwiftUI

struct ContentView: View {
    var body: some View {
        
        NavigationStack{
            
                VStack {
                    
                    Text("G.W.A.A.")
                        .font(.largeTitle)
                        .foregroundStyle(.black.gradient)
                        .padding()
                        .multilineTextAlignment(.center)
                    
                    Divider()
                    
                    Spacer()
                    
                    NavigationLink{
                        
                        Topics()
                        
                    } label: {
                        
                        ZStack{
                            
                            
                            
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 300, height: 100)
                                .foregroundStyle(Color(red: 0.5, green: 0.4,blue: 0.3).gradient)
                            
                            Text("Topics")
                                .foregroundStyle(.black.gradient)
                                .font(.title)
                            
                        }
                    }
                    
                    
                    
                    Button {
                        
                        
                    } label: {
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 300, height: 100)
                                .foregroundStyle(Color(red: 0.3, green: 0.4,blue: 0.6).gradient)
                            
                            Text("Game")
                                .foregroundStyle(.black.gradient)
                                .font(.title)
                        }
                    }
                    
                    Button {
                        
                        
                    } label: {
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 15)
                                .frame(width: 300, height: 100)
                                .foregroundStyle(Color(red: 0.7, green: 0.7,blue: 0.4).gradient)
                            
                            Text("Sources")
                                .foregroundStyle(.black.gradient)
                                .font(.title)
                        }
                    }
                    
                    
                    
                    
                    Spacer()
                    
                    
                }
                .background(Color(red: 0.4, green: 0.6,blue: 0.4).gradient)
                
            }
        
        }
        
    }
