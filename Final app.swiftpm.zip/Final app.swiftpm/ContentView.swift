import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            
            Rectangle()
                .background(Gradient(colors: [.green]))
            
            VStack {
                
                Text("G.W.A.A")
                    .font(.title)
                
                
                
                Divider()
                
                
                
                
                3
                
                
            }
            
            
        }
    }
}
