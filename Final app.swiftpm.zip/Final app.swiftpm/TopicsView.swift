import SwiftUI

struct Topics: View {
    
    @State private var choicesIndex = 0
    
    var choices = ["Disease", "Displacement", "Weather", "Food Production"]
    var choicestexts = ["Disease is spread already easily enough, but with global warming diseases could be spread at an alarming rate. One impact of global warming is the increase in vector ranges. Vectors are carriers of disease, such as, mosquitoes and ticks. The increase of warm weather as a result of global warming allows for these carriers to live and survive in areas they are previously couldn’t. Another way that global warming has effected diseases is by facilitating their spread. Temperatures that result from global warming are altering the way disease is spread. These impacts could cause the death of many individuals due to doctors not finding cures in time, or diseases being stronger leading to mortality.", 
                        "Global warming has contributed to the displacing of people significantly. The extreme weather caused by global warming usually results in the destruction of housing, and services. This removes businesses and shelter from neighborhood, making areas unable to provide for their popultion. As a result of having unsustainable areas, people are forced to migrate to a different area, which ultimatly leads to poverty or other negative impacts.", 
                        "Global warming impacts the weather in many ways. One impact of global warming that stands out most, is the increase in extreme weather conditions. It has increased the intensity and frequency of extreme weather events through altering weather patterns, raising sea levels, and intensifying the water cycle. All of this occurs because when the warmer air holds more moisture, it causes heavier rainfall and increases flooding. These events also lead to longer lasting effects: intense droughts, warmer ocean temperature, stronger hurricanes, tropical cyclones and heatwaves.", 
                        "Global warming has many effects that deplete food production for humans and increase hunger. The extreme weather conditions caused by global warming, when crossing over a farm feild, can cause food to be ripped out. This decreases the avalibility or freshness to food, which ultimatly may result in starvation, or a government not being able to provide for its popultion."]
    
    var body: some View {
        NavigationStack{
            
        
                
                
                
                
                
                VStack{
                    
                    
                    Text("Choose a topic to learn about")
                        .font(.title)
                        .foregroundStyle(.black.gradient)
                        .padding()
                        .multilineTextAlignment(.center)
                    
                    Divider()
                    
                    Spacer()
                    
                        Picker(selection: $choicesIndex, label: Text("Hi")) {
                            
                            
                            ForEach(0 ..< choices.count) {
                                
                                
                                Text(self.choices[$0]).tag($0)
                                    .foregroundStyle(.black.gradient)
                                    .font(.title)
                                
                            }
                            
                            
                            
                            
                        }
                        .pickerStyle(.wheel)
                        
                        
                    Spacer()
                    
                        
                    Text("\(choicestexts[choicesIndex])")
                        
                        .foregroundStyle(.black.gradient)
                        .multilineTextAlignment(.center)
                        .padding()
                        .onChange(of: choicesIndex){
                            
                        }
                    
                    Spacer()
                    
                }
                .background(Color(red: 0.4, green: 0.6,blue: 0.4).gradient)
                
                
                
                
            }
            
            
            
            
            
        }
        
       
    }

