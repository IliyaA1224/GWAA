import SwiftUI

struct Weather: View {
    var body: some View {
        VStack{
            
        }
    }
}
